-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Сен 29 2019 г., 23:00
-- Версия сервера: 10.1.38-MariaDB
-- Версия PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `43design`
--

-- --------------------------------------------------------

--
-- Структура таблицы `web_commentmeta`
--

CREATE TABLE `web_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `web_comments`
--

CREATE TABLE `web_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_comments`
--

INSERT INTO `web_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-09-27 14:11:36', '2019-09-27 11:11:36', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_links`
--

CREATE TABLE `web_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `web_options`
--

CREATE TABLE `web_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_options`
--

INSERT INTO `web_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/43design/src/wordpress', 'yes'),
(2, 'home', 'http://localhost/43design/src', 'yes'),
(3, 'blogname', 'Гильдия дизайнеров', 'yes'),
(4, 'blogdescription', 'Кировской области', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'saloon.as@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:86:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'starck-theme', 'yes'),
(41, 'stylesheet', 'starck-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', '', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'web_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'WPLANG', 'ru_RU', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:6:\"header\";a:0:{}s:7:\"top-bar\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'cron', 'a:6:{i:1569791499;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1569798699;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1569841897;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1569842024;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1569842029;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(104, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'recovery_keys', 'a:1:{s:22:\"zcRLPiGI7XHwxeHUBvG1Yy\";a:2:{s:10:\"hashed_key\";s:34:\"$P$By8xNUHkT7ufNLxqMPQCrAHyOacvSR.\";s:10:\"created_at\";i:1569784258;}}', 'yes'),
(116, 'theme_mods_starck-theme', 'a:5:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1569783222;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:6:\"header\";a:0:{}s:7:\"top-bar\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:9:\"sidebar-1\";a:0:{}}}s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:11:\"custom_logo\";i:7;s:16:\"header_textcolor\";s:6:\"ffffff\";}', 'yes'),
(125, '_site_transient_timeout_browser_9346f2d1cb19dcd36d38d888b651484c', '1570187626', 'no'),
(126, '_site_transient_browser_9346f2d1cb19dcd36d38d888b651484c', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"77.0.3865.90\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(127, '_site_transient_timeout_php_check_0cbcbda5109bcde6b94054595b5c2163', '1570187627', 'no'),
(128, '_site_transient_php_check_0cbcbda5109bcde6b94054595b5c2163', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(130, 'can_compress_scripts', '1', 'no'),
(149, 'new_admin_email', 'saloon.as@gmail.com', 'yes'),
(156, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.3.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.3.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.3\";s:7:\"version\";s:5:\"5.2.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1569757020;s:15:\"version_checked\";s:5:\"5.2.3\";s:12:\"translations\";a:0:{}}', 'no'),
(157, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1569757026;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:0:{}}', 'no'),
(158, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1569783207;s:7:\"checked\";a:3:{s:19:\"generatepress-child\";s:0:\"\";s:13:\"generatepress\";s:5:\"2.3.2\";s:12:\"starck-theme\";s:22:\"1.0.5 (September 2019)\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(159, 'current_theme', 'Starck Theme', 'yes'),
(160, 'theme_mods_generatepress-child', 'a:6:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"font_body_category\";s:10:\"sans-serif\";s:18:\"font_body_variants\";s:70:\"300,300italic,regular,italic,600,600italic,700,700italic,800,800italic\";s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1569586797;s:4:\"data\";a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:6:\"header\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:8:\"footer-5\";a:0:{}s:10:\"footer-bar\";a:0:{}s:7:\"top-bar\";a:0:{}}}}', 'yes'),
(161, 'theme_switched', '', 'yes'),
(162, 'generate_settings', 'a:42:{s:10:\"hide_title\";s:0:\"\";s:12:\"hide_tagline\";s:0:\"\";s:4:\"logo\";s:0:\"\";s:25:\"inline_logo_site_branding\";b:0;s:11:\"retina_logo\";s:0:\"\";s:10:\"logo_width\";s:0:\"\";s:13:\"top_bar_width\";s:4:\"full\";s:19:\"top_bar_inner_width\";s:9:\"contained\";s:17:\"top_bar_alignment\";s:5:\"right\";s:15:\"container_width\";s:4:\"1100\";s:19:\"container_alignment\";s:5:\"boxes\";s:21:\"header_layout_setting\";s:12:\"fluid-header\";s:18:\"header_inner_width\";s:9:\"contained\";s:21:\"nav_alignment_setting\";s:4:\"left\";s:24:\"header_alignment_setting\";s:4:\"left\";s:18:\"nav_layout_setting\";s:9:\"fluid-nav\";s:15:\"nav_inner_width\";s:9:\"contained\";s:20:\"nav_position_setting\";s:16:\"nav-below-header\";s:14:\"nav_drop_point\";s:0:\"\";s:17:\"nav_dropdown_type\";s:5:\"hover\";s:22:\"nav_dropdown_direction\";s:5:\"right\";s:10:\"nav_search\";s:7:\"disable\";s:22:\"content_layout_setting\";s:19:\"separate-containers\";s:14:\"layout_setting\";s:13:\"right-sidebar\";s:19:\"blog_layout_setting\";s:13:\"right-sidebar\";s:21:\"single_layout_setting\";s:13:\"right-sidebar\";s:12:\"post_content\";s:4:\"full\";s:21:\"footer_layout_setting\";s:12:\"fluid-footer\";s:18:\"footer_inner_width\";s:9:\"contained\";s:21:\"footer_widget_setting\";s:1:\"3\";s:20:\"footer_bar_alignment\";s:5:\"right\";s:11:\"back_to_top\";s:0:\"\";s:16:\"background_color\";s:7:\"#efefef\";s:10:\"text_color\";s:7:\"#3a3a3a\";s:10:\"link_color\";s:7:\"#1e73be\";s:16:\"link_color_hover\";s:7:\"#000000\";s:18:\"link_color_visited\";s:0:\"\";s:23:\"font_awesome_essentials\";b:0;s:5:\"icons\";s:4:\"font\";s:11:\"combine_css\";b:0;s:17:\"dynamic_css_cache\";b:0;s:9:\"font_body\";s:9:\"Open Sans\";}', 'yes'),
(163, 'generate_migration_settings', 'a:5:{s:11:\"combine_css\";s:4:\"done\";s:31:\"font_awesome_essentials_updated\";s:4:\"true\";s:22:\"skip_dynamic_css_cache\";s:4:\"true\";s:20:\"default_font_updated\";s:4:\"true\";s:25:\"blog_post_content_preview\";s:4:\"true\";}', 'yes'),
(164, 'generate_dynamic_css_output', 'body{background-color:#efefef;color:#3a3a3a;}a, a:visited{color:#1e73be;}a:hover, a:focus, a:active{color:#000000;}body .grid-container{max-width:1100px;}body, button, input, select, textarea{font-family:-apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";}.entry-content > [class*=\"wp-block-\"]:not(:last-child){margin-bottom:1.5em;}.main-navigation .main-nav ul ul li a{font-size:14px;}@media (max-width:768px){.main-title{font-size:30px;}h1{font-size:30px;}h2{font-size:25px;}}.top-bar{background-color:#636363;color:#ffffff;}.top-bar a,.top-bar a:visited{color:#ffffff;}.top-bar a:hover{color:#303030;}.site-header{background-color:#ffffff;color:#3a3a3a;}.site-header a,.site-header a:visited{color:#3a3a3a;}.main-title a,.main-title a:hover,.main-title a:visited{color:#222222;}.site-description{color:#757575;}.main-navigation,.main-navigation ul ul{background-color:#222222;}.main-navigation .main-nav ul li a,.menu-toggle{color:#ffffff;}.main-navigation .main-nav ul li:hover > a,.main-navigation .main-nav ul li:focus > a, .main-navigation .main-nav ul li.sfHover > a{color:#ffffff;background-color:#3f3f3f;}button.menu-toggle:hover,button.menu-toggle:focus,.main-navigation .mobile-bar-items a,.main-navigation .mobile-bar-items a:hover,.main-navigation .mobile-bar-items a:focus{color:#ffffff;}.main-navigation .main-nav ul li[class*=\"current-menu-\"] > a{color:#ffffff;background-color:#3f3f3f;}.main-navigation .main-nav ul li[class*=\"current-menu-\"] > a:hover,.main-navigation .main-nav ul li[class*=\"current-menu-\"].sfHover > a{color:#ffffff;background-color:#3f3f3f;}.navigation-search input[type=\"search\"],.navigation-search input[type=\"search\"]:active{color:#3f3f3f;background-color:#3f3f3f;}.navigation-search input[type=\"search\"]:focus{color:#ffffff;background-color:#3f3f3f;}.main-navigation ul ul{background-color:#3f3f3f;}.main-navigation .main-nav ul ul li a{color:#ffffff;}.main-navigation .main-nav ul ul li:hover > a,.main-navigation .main-nav ul ul li:focus > a,.main-navigation .main-nav ul ul li.sfHover > a{color:#ffffff;background-color:#4f4f4f;}.main-navigation .main-nav ul ul li[class*=\"current-menu-\"] > a{color:#ffffff;background-color:#4f4f4f;}.main-navigation .main-nav ul ul li[class*=\"current-menu-\"] > a:hover,.main-navigation .main-nav ul ul li[class*=\"current-menu-\"].sfHover > a{color:#ffffff;background-color:#4f4f4f;}.separate-containers .inside-article, .separate-containers .comments-area, .separate-containers .page-header, .one-container .container, .separate-containers .paging-navigation, .inside-page-header{background-color:#ffffff;}.entry-meta{color:#595959;}.entry-meta a,.entry-meta a:visited{color:#595959;}.entry-meta a:hover{color:#1e73be;}.sidebar .widget{background-color:#ffffff;}.sidebar .widget .widget-title{color:#000000;}.footer-widgets{background-color:#ffffff;}.footer-widgets .widget-title{color:#000000;}.site-info{color:#ffffff;background-color:#222222;}.site-info a,.site-info a:visited{color:#ffffff;}.site-info a:hover{color:#606060;}.footer-bar .widget_nav_menu .current-menu-item a{color:#606060;}input[type=\"text\"],input[type=\"email\"],input[type=\"url\"],input[type=\"password\"],input[type=\"search\"],input[type=\"tel\"],input[type=\"number\"],textarea,select{color:#666666;background-color:#fafafa;border-color:#cccccc;}input[type=\"text\"]:focus,input[type=\"email\"]:focus,input[type=\"url\"]:focus,input[type=\"password\"]:focus,input[type=\"search\"]:focus,input[type=\"tel\"]:focus,input[type=\"number\"]:focus,textarea:focus,select:focus{color:#666666;background-color:#ffffff;border-color:#bfbfbf;}button,html input[type=\"button\"],input[type=\"reset\"],input[type=\"submit\"],a.button,a.button:visited,a.wp-block-button__link:not(.has-background){color:#ffffff;background-color:#666666;}button:hover,html input[type=\"button\"]:hover,input[type=\"reset\"]:hover,input[type=\"submit\"]:hover,a.button:hover,button:focus,html input[type=\"button\"]:focus,input[type=\"reset\"]:focus,input[type=\"submit\"]:focus,a.button:focus,a.wp-block-button__link:not(.has-background):active,a.wp-block-button__link:not(.has-background):focus,a.wp-block-button__link:not(.has-background):hover{color:#ffffff;background-color:#3f3f3f;}.generate-back-to-top,.generate-back-to-top:visited{background-color:rgba( 0,0,0,0.4 );color:#ffffff;}.generate-back-to-top:hover,.generate-back-to-top:focus{background-color:rgba( 0,0,0,0.6 );color:#ffffff;}.entry-content .alignwide, body:not(.no-sidebar) .entry-content .alignfull{margin-left:-40px;width:calc(100% + 80px);max-width:calc(100% + 80px);}.rtl .menu-item-has-children .dropdown-menu-toggle{padding-left:20px;}.rtl .main-navigation .main-nav ul li.menu-item-has-children > a{padding-right:20px;}@media (max-width:768px){.separate-containers .inside-article, .separate-containers .comments-area, .separate-containers .page-header, .separate-containers .paging-navigation, .one-container .site-content, .inside-page-header{padding:30px;}.entry-content .alignwide, body:not(.no-sidebar) .entry-content .alignfull{margin-left:-30px;width:calc(100% + 60px);max-width:calc(100% + 60px);}}.one-container .sidebar .widget{padding:0px;}', 'yes'),
(165, 'generate_dynamic_css_cached_version', '2.3.2', 'yes'),
(166, 'generate_db_version', '2.3.2', 'no'),
(167, 'generate_update_core_typography', 'true', 'yes'),
(174, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(175, 'starck_settings', 'a:15:{s:22:\"content_header_setting\";s:8:\"disabled\";s:18:\"main_bound_setting\";s:10:\"full-width\";s:19:\"breadcrumbs_setting\";s:1:\"0\";s:9:\"scroll_up\";b:0;s:14:\"layout_setting\";s:10:\"no-sidebar\";s:19:\"blog_layout_setting\";s:10:\"no-sidebar\";s:21:\"single_layout_setting\";s:10:\"no-sidebar\";s:21:\"footer_widget_setting\";s:1:\"0\";s:21:\"header_widget_setting\";s:8:\"disabled\";s:22:\"top_bar_layout_setting\";s:1:\"0\";s:18:\"branding_alignment\";s:6:\"center\";s:17:\"branding_vertical\";s:1:\"0\";s:20:\"nav_position_setting\";s:5:\"above\";s:13:\"nav_alignment\";s:5:\"right\";s:10:\"nav_burger\";b:1;}', 'yes'),
(207, '_site_transient_timeout_theme_roots', '1569785005', 'no'),
(208, '_site_transient_theme_roots', 'a:3:{s:19:\"generatepress-child\";s:7:\"/themes\";s:13:\"generatepress\";s:7:\"/themes\";s:12:\"starck-theme\";s:7:\"/themes\";}', 'no'),
(210, 'theme_mods_generatepress', 'a:6:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"font_body_category\";s:10:\"sans-serif\";s:18:\"font_body_variants\";s:70:\"300,300italic,regular,italic,600,600italic,700,700italic,800,800italic\";s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1569784126;s:4:\"data\";a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:6:\"header\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:8:\"footer-5\";a:0:{}s:10:\"footer-bar\";a:0:{}s:7:\"top-bar\";a:0:{}}}}', 'yes'),
(212, 'recovery_mode_email_last_sent', '1569784258', 'yes'),
(216, 'category_children', 'a:0:{}', 'yes');

-- --------------------------------------------------------

--
-- Структура таблицы `web_postmeta`
--

CREATE TABLE `web_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_postmeta`
--

INSERT INTO `web_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1569583131:1'),
(4, 6, '_wp_attached_file', '2019/09/Logo_GD_200x200.png'),
(5, 6, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:27:\"2019/09/Logo_GD_200x200.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Logo_GD_200x200-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"mini-thumbnail\";a:4:{s:4:\"file\";s:27:\"Logo_GD_200x200-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(6, 5, '_wp_trash_meta_status', 'publish'),
(7, 5, '_wp_trash_meta_time', '1569583190'),
(8, 7, '_wp_attached_file', '2019/09/Logo.png'),
(9, 7, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:16:\"2019/09/Logo.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"Logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"mini-thumbnail\";a:4:{s:4:\"file\";s:16:\"Logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(10, 7, '_edit_lock', '1569584425:1'),
(11, 7, '_edit_last', '1'),
(12, 8, '_wp_attached_file', '2019/09/Logo.jpg'),
(13, 8, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:492;s:6:\"height\";i:267;s:4:\"file\";s:16:\"2019/09/Logo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"Logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"Logo-300x163.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:163;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(14, 9, '_wp_trash_meta_status', 'publish'),
(15, 9, '_wp_trash_meta_time', '1569587661'),
(16, 10, '_edit_lock', '1569587703:1'),
(17, 10, '_wp_trash_meta_status', 'publish'),
(18, 10, '_wp_trash_meta_time', '1569587718'),
(19, 11, '_edit_lock', '1569587994:1'),
(20, 11, '_wp_trash_meta_status', 'publish'),
(21, 11, '_wp_trash_meta_time', '1569588013'),
(22, 12, '_wp_trash_meta_status', 'publish'),
(23, 12, '_wp_trash_meta_time', '1569604915'),
(24, 13, '_edit_lock', '1569788119:1'),
(26, 15, '_wp_attached_file', 'anons_pic_long.jpg'),
(27, 15, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:264;s:4:\"file\";s:18:\"anons_pic_long.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"anons_pic_long-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"anons_pic_long-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"category-thumb\";a:4:{s:4:\"file\";s:26:\"anons_pic_long-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"mini-thumbnail\";a:4:{s:4:\"file\";s:26:\"anons_pic_long-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"anons_pic_long-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(28, 1, '_wp_trash_meta_status', 'publish'),
(29, 1, '_wp_trash_meta_time', '1569780069'),
(30, 1, '_wp_desired_post_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(31, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(34, 13, '_thumbnail_id', '15'),
(39, 22, '_edit_lock', '1569790748:1');

-- --------------------------------------------------------

--
-- Структура таблицы `web_posts`
--

CREATE TABLE `web_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_posts`
--

INSERT INTO `web_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-09-27 14:11:36', '2019-09-27 11:11:36', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'trash', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80__trashed', '', '', '2019-09-29 21:01:09', '2019-09-29 18:01:09', '', 0, 'http://localhost/43design/src/wordpress/?p=1', 0, 'post', '', 1),
(2, 1, '2019-09-27 14:11:36', '2019-09-27 11:11:36', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://localhost/43design/src/wordpress/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2019-09-27 14:11:36', '2019-09-27 11:11:36', '', 0, 'http://localhost/43design/src/wordpress/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-09-27 14:11:36', '2019-09-27 11:11:36', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://localhost/43design/src/wordpress.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-09-27 14:11:36', '2019-09-27 11:11:36', '', 0, 'http://localhost/43design/src/wordpress/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-09-27 14:13:49', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-09-27 14:13:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/43design/src/wordpress/?p=4', 0, 'post', '', 0),
(5, 1, '2019-09-27 14:19:49', '2019-09-27 11:19:49', '{\n    \"blogdescription\": {\n        \"value\": \"\\u041a\\u0438\\u0440\\u043e\\u0432\\u0441\\u043a\\u043e\\u0439 \\u043e\\u0431\\u043b\\u0430\\u0441\\u0442\\u0438\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 11:17:55\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '97f30a0d-da98-4af3-be15-f269072c2e71', '', '', '2019-09-27 14:19:49', '2019-09-27 11:19:49', '', 0, 'http://localhost/43design/src/wordpress/?p=5', 0, 'customize_changeset', '', 0),
(6, 1, '2019-09-27 14:18:33', '2019-09-27 11:18:33', '', 'Logo_GD_200x200', '', 'inherit', 'open', 'closed', '', 'logo_gd_200x200', '', '', '2019-09-27 14:18:33', '2019-09-27 11:18:33', '', 0, '//localhost/wp-content/uploads/2019/09/Logo_GD_200x200.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2019-09-27 14:32:05', '2019-09-27 11:32:05', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-09-27 14:34:44', '2019-09-27 11:34:44', '', 0, '//localhost/wp-content/uploads/2019/09/Logo.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2019-09-27 15:07:19', '2019-09-27 12:07:19', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo-2', '', '', '2019-09-27 15:07:19', '2019-09-27 12:07:19', '', 0, '//localhost/wp-content/uploads/2019/09/Logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2019-09-27 15:34:21', '2019-09-27 12:34:21', '{\n    \"starck-theme::custom_logo\": {\n        \"value\": 7,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:34:21\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3ac517b5-7f5a-4302-84e3-2c2571982589', '', '', '2019-09-27 15:34:21', '2019-09-27 12:34:21', '', 0, 'http://localhost/43design/src/3ac517b5-7f5a-4302-84e3-2c2571982589/', 0, 'customize_changeset', '', 0),
(10, 1, '2019-09-27 15:35:18', '2019-09-27 12:35:18', '{\n    \"starck-theme::header_textcolor\": {\n        \"value\": \"#ffffff\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:35:03\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8bb682f6-91d1-48d4-8d0c-700327004f54', '', '', '2019-09-27 15:35:18', '2019-09-27 12:35:18', '', 0, 'http://localhost/43design/src/?p=10', 0, 'customize_changeset', '', 0),
(11, 1, '2019-09-27 15:40:13', '2019-09-27 12:40:13', '{\n    \"starck_settings[content_header_setting]\": {\n        \"value\": \"disabled\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[main_bound_setting]\": {\n        \"value\": \"full-width\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[breadcrumbs_setting]\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[scroll_up]\": {\n        \"value\": false,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[layout_setting]\": {\n        \"value\": \"no-sidebar\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[blog_layout_setting]\": {\n        \"value\": \"no-sidebar\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[single_layout_setting]\": {\n        \"value\": \"no-sidebar\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[footer_widget_setting]\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:38:54\"\n    },\n    \"starck_settings[header_widget_setting]\": {\n        \"value\": \"disabled\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[top_bar_layout_setting]\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[branding_alignment]\": {\n        \"value\": \"center\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[branding_vertical]\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[nav_position_setting]\": {\n        \"value\": \"inline\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[nav_alignment]\": {\n        \"value\": \"right\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    },\n    \"starck_settings[nav_burger]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 12:39:54\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd2e8cccc-388e-48d9-8b26-b681b2b7bdef', '', '', '2019-09-27 15:40:13', '2019-09-27 12:40:13', '', 0, 'http://localhost/43design/src/?p=11', 0, 'customize_changeset', '', 0),
(12, 1, '2019-09-27 20:21:54', '2019-09-27 17:21:54', '{\n    \"starck_settings[nav_position_setting]\": {\n        \"value\": \"above\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 17:21:54\"\n    },\n    \"starck_settings[nav_burger]\": {\n        \"value\": true,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-09-27 17:21:54\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f2cdf365-5041-4abc-be38-2786fb59995a', '', '', '2019-09-27 20:21:54', '2019-09-27 17:21:54', '', 0, 'http://localhost/43design/src/f2cdf365-5041-4abc-be38-2786fb59995a/', 0, 'customize_changeset', '', 0),
(13, 1, '2019-09-29 20:47:29', '2019-09-29 17:47:29', '<!-- wp:paragraph -->\n<p><strong>ВЕТЕР ПЕРЕМЕН</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', 'В программе \"Квартирный вопрос\" на НТВ будет показан интерьер по проекту \"Ветер перемен\" члена Гильдии дизайнеров Кировской области Сергея Орлова.', 'publish', 'closed', 'closed', '', '%d1%81%d0%b5%d1%80%d0%b3%d0%b5%d0%b9-%d0%be%d1%80%d0%bb%d0%be%d0%b2-%d0%b2-%d0%bf%d1%80%d0%be%d0%b3%d1%80%d0%b0%d0%bc%d0%bc%d0%b5-%d0%ba%d0%b2%d0%b0%d1%80%d1%82%d0%b8%d1%80%d0%bd%d1%8b%d0%b9-%d0%b2', '', '', '2019-09-29 23:09:52', '2019-09-29 20:09:52', '', 0, 'http://localhost/43design/src/?p=13', 0, 'post', '', 0),
(14, 1, '2019-09-29 20:47:29', '2019-09-29 17:47:29', '<!-- wp:heading {\"level\":3} -->\n<h3>ВЕТЕР ПЕРЕМЕН</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', 'В программе \"Квартирный вопрос\" на НТВ будет показан интерьер по проекту \"Ветер перемен\" члена Гильдии дизайнеров Кировской области Сергея Орлова.', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-09-29 20:47:29', '2019-09-29 17:47:29', '', 13, 'http://localhost/43design/src/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2019-09-29 21:01:01', '2019-09-29 18:01:01', '', 'anons_pic_long', '', 'inherit', 'open', 'closed', '', 'anons_pic_long', '', '', '2019-09-29 21:01:01', '2019-09-29 18:01:01', '', 0, 'http://localhost/43design/src/wp-content/uploads/anons_pic_long.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2019-09-29 21:01:09', '2019-09-29 18:01:09', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-09-29 21:01:09', '2019-09-29 18:01:09', '', 1, 'http://localhost/43design/src/1-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2019-09-29 21:02:12', '2019-09-29 18:02:12', '<!-- wp:heading {\"level\":3} -->\n<h3>ВЕТЕР ПЕРЕМЕН</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":15,\"align\":\"center\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"http://localhost/43design/src/wp-content/uploads/anons_pic_long.jpg\" alt=\"\" class=\"wp-image-15\"/></figure></div>\n<!-- /wp:image -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', 'В программе \"Квартирный вопрос\" на НТВ будет показан интерьер по проекту \"Ветер перемен\" члена Гильдии дизайнеров Кировской области Сергея Орлова.', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-09-29 21:02:12', '2019-09-29 18:02:12', '', 13, 'http://localhost/43design/src/13-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2019-09-29 21:11:06', '2019-09-29 18:11:06', '<!-- wp:heading {\"level\":3} -->\n<h3>ВЕТЕР ПЕРЕМЕН</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', 'В программе \"Квартирный вопрос\" на НТВ будет показан интерьер по проекту \"Ветер перемен\" члена Гильдии дизайнеров Кировской области Сергея Орлова.', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-09-29 21:11:06', '2019-09-29 18:11:06', '', 13, 'http://localhost/43design/src/13-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2019-09-29 22:11:44', '2019-09-29 19:11:44', '<!-- wp:heading {\"level\":3} -->\n<h3>ВЕТЕР ПЕРЕМЕН</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-09-29 22:11:44', '2019-09-29 19:11:44', '', 13, 'http://localhost/43design/src/13-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2019-09-29 22:14:42', '2019-09-29 19:14:42', '<!-- wp:paragraph -->\n<p><strong>ВЕТЕР ПЕРЕМЕН</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>У героев – угловая квартира на третьем этаже старого сталинского дома. На фоне новых сильно выделяется старое деревянное окно. Изнутри оно заложено: дело в том, что прежние хозяева квартиры не знали, как в комнате, где есть две смежные стены с окнами, расставить мебель. А мы – знаем! Поэтому окно разошьем, впустим сюда свет и воздух. Мебели при этом будет предостаточно, и спальня будет превращаться в гостиную, а точнее – уютный грузинский дворик с арками, увитыми зеленью. </p>\n<!-- /wp:paragraph -->', 'Сергей Орлов в программе \"Квартирный вопрос\" на НТВ', 'В программе \"Квартирный вопрос\" на НТВ будет показан интерьер по проекту \"Ветер перемен\" члена Гильдии дизайнеров Кировской области Сергея Орлова.', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-09-29 22:14:42', '2019-09-29 19:14:42', '', 13, 'http://localhost/43design/src/13-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2019-09-29 23:18:35', '2019-09-29 20:18:35', '<!-- wp:paragraph -->\n<p>УТВЕРЖДЕНО<br>Решением Совета<br>Гильдии дизайнеров<br>Кировской области</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>1. ВВЕДЕНИЕ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.1. Членами Гильдии дизайнеров Кировской области при ВТПП (далее ГДКО) могут быть граждане Российской Федерации, иностранные граждане и лица без гражданства, достигшие 18 лет, — профессиональные дизайнеры, архитекторы и другие специалисты, работающие в области дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Кандидат должен быть:</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>добросовестным налогоплательщиком (быть учредителем или соучредителем коммерческой организации, оказывающей дизайнерские услуги или индивидуальным предпринимателем или состоять в трудовых отношениях с организацией, оказывающей дизайнерские услуги);</li><li>принимать участие в выставке-конкурсе ВТПП «Сфера дизайна» не реже одного раза в два года; </li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>1.2. Прием в члены Гильдии осуществляется решением Совета ГДКО на основании личного заявления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.3. Состав Совета Гильдии формируется общим очным или заочным голосованием в количестве 5 человек. Совет назначает из своего состава председателя и секретаря и оформляет свое решение протоколом.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.4. Периодичность приема в Гильдию не должна быть реже одного раза в квартал при наличии обращений от кандидатов.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>2. ПОРЯДОК ПРИЕМА.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.1. Вступающие в Гильдию передают в  Совет гильдии заявление в свободной форме и другие необходимые документы и материалы. Заявления кандидатов регистрируются и рассматриваются в порядке их поступления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.2. На основе поступившего заявления, документов и других материалов, характеризующих кандидата, комиссии принимают решение о приеме в Гильдию. Решение принимается простым большинством голосов от числа присутствующих на заседании при наличии кворума. При равенстве голосов преимущество получает решение, за которое проголосовал председатель Совета. Решение Совета оформляется протоколом в двух экземплярах. Протокол подписывают председатель и секретарь заседания.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.3. Отказ в приеме в члены Гильдии должен быть мотивирован.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>3. ПРЕДСТАВЛЯЕМЫЕ МАТЕРИАЛЫ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Для рассмотрения вопроса о приеме в члены Гильдии кандидат (физическое лицо) представляет следующие документы:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>заявление о приеме в свободной форме. К заявлению прилагается портфолио реализованных объектов (в бумажном или электронном виде по выбору кандидата)</li><li>документ, подтверждающий, что кандидат является добросовестным налогоплательщиком (копию свидетельства ИП, выписку из устава или справку с места работы);</li><li>копию свидетельства об образовании;</li><li>копии дипломов, подтверждающих ученую степень, ученое или почетное звание (если есть);</li><li>краткую автобиографию;</li><li>рекомендации двух членов Гильдии, знающих кандидата по совместной работе (не распространяется на победителей конкурса-выставки «Сфера-дизайна» ВТПП),</li><li>копии собственных публикаций и публикаций о своей деятельности в прессе (если есть);</li><li>копии лауреатских и наградных дипломов и свидетельств (если есть);</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><br><strong>4. ПОЧЕТНЫЕ ЧЛЕНЫ ГИЛЬДИИ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.1. Известные отечественные и зарубежные специалисты по решению Совета могут быть избраны Почетными членами Гильдии без приобретения прав и обязанностей в Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.2. Почетными членами Гильдии избираются крупнейшие специалисты дизайна, пользующиеся авторитетом среди дизайнерской общественности, внесшие большой вклад в развитие российского дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.3. В почетные члены по желанию могут перейти действительные члены Гильдии, достигшие возраста 70 лет, представившие соответствующее заявление в адрес Совета Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.4. Почетные члены избираются открытым голосованием простым большинством голосов от числа присутствующих на заседании Совета Гильдии.</p>\n<!-- /wp:paragraph -->', 'Положение о приеме в Гильдию дизайнеров Кировской области при Вятской торгово-промышленной палате Кировской области', '', 'publish', 'closed', 'closed', '', 'admission', '', '', '2019-09-29 23:45:50', '2019-09-29 20:45:50', '', 0, 'http://localhost/43design/src/?page_id=22', 0, 'page', '', 0),
(23, 1, '2019-09-29 23:18:35', '2019-09-29 20:18:35', '<!-- wp:paragraph -->\n<p>УТВЕРЖДЕНО<br>Решением Совета<br>Гильдии дизайнеров<br>Кировской области</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>1. ВВЕДЕНИЕ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.1. Членами Гильдии дизайнеров Кировской области при ВТПП (далее ГДКО) могут быть граждане Российской Федерации, иностранные граждане и лица без гражданства, достигшие 18 лет, — профессиональные дизайнеры, архитекторы и другие специалисты, работающие в области дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Кандидат должен быть:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>добросовестным налогоплательщиком (быть учредителем или соучередителем коммерческой организации, оказывающей дизайнерские услуги или индивидуальным предпринимателем или состоять в трудовых отношениях с организацией, оказывающей дизайнерские услуги);</li><li>принимать участие в выставке-конкурсе ВТПП «Сфера дизайна» не реже одного раза в два года.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><br>1.2. Прием в члены Гильдии осуществляется решением Совета ГДКО на основании личного заявления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.3. Состав Совета Гильдии формируется общим очным или заочным голосованием в количестве 5 человек. Совет назначает из своего состава председателя и секретаря и оформляет свое решение протоколом.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.5. Периодичность приема в Гильдию не должна быть реже одного раза в квартал при наличии обращений от кандидатов.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br><strong>2. ПОРЯДОК ПРИЕМА.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>2.1. Вступающие в Гильдию передают в&nbsp; Совет гильдии заявление в свободной форме и другие необходимые документы и материалы. Заявления кандидатов регистрируются и рассматриваются в порядке их поступления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>2.2. На основе поступившего заявления, документов и других материалов, характеризующих кандидата, комиссии принимают решение о приеме в Гильдию. Решение принимается простым большинством голосов от числа присутствующих на заседании при наличии кворума. При равенстве голосов преимущество получает решение, за которое проголосовал председатель Совета. Решение Совета оформляется протоколом в двух экземплярах. Протокол подписывают председатель и секретарь заседания.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>2.3. Отказ в приеме в члены Гильдии должен быть мотивирован.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>3. ПРЕДСТАВЛЯЕМЫЕ МАТЕРИАЛЫ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Для рассмотрения вопроса о приеме в члены Гильдии кандидат (физическое лицо) представляет следующие документы:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>заявление о приеме в свободной форме. К заявлению прилагается портфолио реализованных объектов (в бумажном или электронном виде по выбору кандидата)</li><li>документ, подтверждающий, что кандидат является добросовестным налогоплательщиком (копию свидетельства ИП, выписку из устава или справку с места работы);</li><li>копию свидетельства об образовании;</li><li>копии дипломов, подтверждающих ученую степень, ученое или почетное звание (если есть);</li><li>краткую автобиографию;</li><li>рекомендации двух членов Гильдии, знающих кандидата по совместной работе (не распространяется на победителей конкурса-выставки «Сфера-дизайна» ВТПП),</li><li>копии собственных публикаций и публикаций о своей деятельности в прессе (если есть);</li><li>копии лауреатских и наградных дипломов и свидетельств (если есть);</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><br><strong>4. ПОЧЕТНЫЕ ЧЛЕНЫ ГИЛЬДИИ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.1. Известные отечественные и зарубежные специалисты по решению Совета могут быть избраны Почетными членами Гильдии без приобретения прав и обязанностей в Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>4.2. Почетными членами Гильдии избираются крупнейшие специалисты дизайна, пользующиеся авторитетом среди дизайнерской общественности, внесшие большой вклад в развитие российского дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>4.3. В почетные члены по желанию могут перейти действительные члены Гильдии, достигшие возраста 70 лет, представившие соответствующее заявление в адрес Совета Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>4.4. Почетные члены избираются открытым голосованием простым большинством голосов от числа присутствующих на заседании Совета Гильдии.</p>\n<!-- /wp:paragraph -->', 'Положение о приеме в Гильдию дизайнеров Кировской области при Вятской торгово-промышленной палате Кировской области', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2019-09-29 23:18:35', '2019-09-29 20:18:35', '', 22, 'http://localhost/43design/src/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2019-09-29 23:25:32', '2019-09-29 20:25:32', '<!-- wp:paragraph -->\n<p>УТВЕРЖДЕНО<br>Решением Совета<br>Гильдии дизайнеров<br>Кировской области</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>1. ВВЕДЕНИЕ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.1. Членами Гильдии дизайнеров Кировской области при ВТПП (далее ГДКО) могут быть граждане Российской Федерации, иностранные граждане и лица без гражданства, достигшие 18 лет, — профессиональные дизайнеры, архитекторы и другие специалисты, работающие в области дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Кандидат должен быть:</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>добросовестным налогоплательщиком (быть учредителем или соучредителем коммерческой организации, оказывающей дизайнерские услуги или индивидуальным предпринимателем или состоять в трудовых отношениях с организацией, оказывающей дизайнерские услуги);</li><li>принимать участие в выставке-конкурсе ВТПП «Сфера дизайна» не реже одного раза в два года; </li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>1.2. Прием в члены Гильдии осуществляется решением Совета ГДКО на основании личного заявления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.3. Состав Совета Гильдии формируется общим очным или заочным голосованием в количестве 5 человек. Совет назначает из своего состава председателя и секретаря и оформляет свое решение протоколом.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.4. Периодичность приема в Гильдию не должна быть реже одного раза в квартал при наличии обращений от кандидатов.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>2. ПОРЯДОК ПРИЕМА.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.1. Вступающие в Гильдию передают в  Совет гильдии заявление в свободной форме и другие необходимые документы и материалы. Заявления кандидатов регистрируются и рассматриваются в порядке их поступления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.2. На основе поступившего заявления, документов и других материалов, характеризующих кандидата, комиссии принимают решение о приеме в Гильдию. Решение принимается простым большинством голосов от числа присутствующих на заседании при наличии кворума. При равенстве голосов преимущество получает решение, за которое проголосовал председатель Совета. Решение Совета оформляется протоколом в двух экземплярах. Протокол подписывают председатель и секретарь заседания.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.3. Отказ в приеме в члены Гильдии должен быть мотивирован.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>3. ПРЕДСТАВЛЯЕМЫЕ МАТЕРИАЛЫ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Для рассмотрения вопроса о приеме в члены Гильдии кандидат (физическое лицо) представляет следующие документы:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>заявление о приеме в свободной форме. К заявлению прилагается портфолио реализованных объектов (в бумажном или электронном виде по выбору кандидата)</li><li>документ, подтверждающий, что кандидат является добросовестным налогоплательщиком (копию свидетельства ИП, выписку из устава или справку с места работы);</li><li>копию свидетельства об образовании;</li><li>копии дипломов, подтверждающих ученую степень, ученое или почетное звание (если есть);</li><li>краткую автобиографию;</li><li>рекомендации двух членов Гильдии, знающих кандидата по совместной работе (не распространяется на победителей конкурса-выставки «Сфера-дизайна» ВТПП),</li><li>копии собственных публикаций и публикаций о своей деятельности в прессе (если есть);</li><li>копии лауреатских и наградных дипломов и свидетельств (если есть);</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><br><strong>4. ПОЧЕТНЫЕ ЧЛЕНЫ ГИЛЬДИИ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.1. Известные отечественные и зарубежные специалисты по решению Совета могут быть избраны Почетными членами Гильдии без приобретения прав и обязанностей в Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.2. Почетными членами Гильдии избираются крупнейшие специалисты дизайна, пользующиеся авторитетом среди дизайнерской общественности, внесшие большой вклад в развитие российского дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.3. В почетные члены по желанию могут перейти действительные члены Гильдии, достигшие возраста 70 лет, представившие соответствующее заявление в адрес Совета Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.4. Почетные члены избираются открытым голосованием простым большинством голосов от числа присутствующих на заседании Совета Гильдии.</p>\n<!-- /wp:paragraph -->', 'Положение о приеме в Гильдию дизайнеров Кировской области при Вятской торгово-промышленной палате Кировской области', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2019-09-29 23:25:32', '2019-09-29 20:25:32', '', 22, 'http://localhost/43design/src/22-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2019-09-29 23:52:16', '2019-09-29 20:52:16', '<!-- wp:paragraph -->\n<p>УТВЕРЖДЕНО<br>Решением Совета<br>Гильдии дизайнеров<br>Кировской области</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>1. ВВЕДЕНИЕ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.1. Членами Гильдии дизайнеров Кировской области при ВТПП (далее ГДКО) могут быть граждане Российской Федерации, иностранные граждане и лица без гражданства, достигшие 18 лет, — профессиональные дизайнеры, архитекторы и другие специалисты, работающие в области дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Кандидат должен быть:</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>добросовестным налогоплательщиком (быть учредителем или соучредителем коммерческой организации, оказывающей дизайнерские услуги или индивидуальным предпринимателем или состоять в трудовых отношениях с организацией, оказывающей дизайнерские услуги);</li><li>принимать участие в выставке-конкурсе ВТПП «Сфера дизайна» не реже одного раза в два года; </li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>1.2. Прием в члены Гильдии осуществляется решением Совета ГДКО на основании личного заявления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.3. Состав Совета Гильдии формируется общим очным или заочным голосованием в количестве 5 человек. Совет назначает из своего состава председателя и секретаря и оформляет свое решение протоколом.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1.4. Периодичность приема в Гильдию не должна быть реже одного раза в квартал при наличии обращений от кандидатов.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>2. ПОРЯДОК ПРИЕМА.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.1. Вступающие в Гильдию передают в  Совет гильдии заявление в свободной форме и другие необходимые документы и материалы. Заявления кандидатов регистрируются и рассматриваются в порядке их поступления.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.2. На основе поступившего заявления, документов и других материалов, характеризующих кандидата, комиссии принимают решение о приеме в Гильдию. Решение принимается простым большинством голосов от числа присутствующих на заседании при наличии кворума. При равенстве голосов преимущество получает решение, за которое проголосовал председатель Совета. Решение Совета оформляется протоколом в двух экземплярах. Протокол подписывают председатель и секретарь заседания.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2.3. Отказ в приеме в члены Гильдии должен быть мотивирован.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>3. ПРЕДСТАВЛЯЕМЫЕ МАТЕРИАЛЫ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Для рассмотрения вопроса о приеме в члены Гильдии кандидат (физическое лицо) представляет следующие документы:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>заявление о приеме в свободной форме. К заявлению прилагается портфолио реализованных объектов (в бумажном или электронном виде по выбору кандидата)</li><li>документ, подтверждающий, что кандидат является добросовестным налогоплательщиком (копию свидетельства ИП, выписку из устава или справку с места работы);</li><li>копию свидетельства об образовании;</li><li>копии дипломов, подтверждающих ученую степень, ученое или почетное звание (если есть);</li><li>краткую автобиографию;</li><li>рекомендации двух членов Гильдии, знающих кандидата по совместной работе (не распространяется на победителей конкурса-выставки «Сфера-дизайна» ВТПП),</li><li>копии собственных публикаций и публикаций о своей деятельности в прессе (если есть);</li><li>копии лауреатских и наградных дипломов и свидетельств (если есть);</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><br><strong>4. ПОЧЕТНЫЕ ЧЛЕНЫ ГИЛЬДИИ</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.1. Известные отечественные и зарубежные специалисты по решению Совета могут быть избраны Почетными членами Гильдии без приобретения прав и обязанностей в Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.2. Почетными членами Гильдии избираются крупнейшие специалисты дизайна, пользующиеся авторитетом среди дизайнерской общественности, внесшие большой вклад в развитие российского дизайна.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.3. В почетные члены по желанию могут перейти действительные члены Гильдии, достигшие возраста 70 лет, представившие соответствующее заявление в адрес Совета Гильдии.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>4.4. Почетные члены избираются открытым голосованием простым большинством голосов от числа присутствующих на заседании Совета Гильдии.</p>\n<!-- /wp:paragraph -->', 'Положение о приеме в Гильдию дизайнеров Кировской области при Вятской торгово-промышленной палате Кировской области', '', 'inherit', 'closed', 'closed', '', '22-autosave-v1', '', '', '2019-09-29 23:52:16', '2019-09-29 20:52:16', '', 22, 'http://localhost/43design/src/22-autosave-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_termmeta`
--

CREATE TABLE `web_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `web_terms`
--

CREATE TABLE `web_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_terms`
--

INSERT INTO `web_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Top', 'top', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_term_relationships`
--

CREATE TABLE `web_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_term_relationships`
--

INSERT INTO `web_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(13, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_term_taxonomy`
--

CREATE TABLE `web_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_term_taxonomy`
--

INSERT INTO `web_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_usermeta`
--

CREATE TABLE `web_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_usermeta`
--

INSERT INTO `web_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'web_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'web_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"cc0c6b17e2915ea079d47c8e2e42079d9b4d4eae3bc388fbba9d06455eb0721c\";a:4:{s:10:\"expiration\";i:1569948405;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:102:\"Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1569775605;}}'),
(17, 1, 'web_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'web_user-settings', 'libraryContent=browse&mfold=o'),
(19, 1, 'web_user-settings-time', '1569586780'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `web_users`
--

CREATE TABLE `web_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `web_users`
--

INSERT INTO `web_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BIESSpT.ZymIaag/amr.jOzVJH847t0', 'admin', 'saloon.as@gmail.com', '', '2019-09-27 11:11:35', '1569582778:$P$Bk21COSfkhdKtdcmn9dIIyKRT6ghTA/', 0, 'admin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `web_commentmeta`
--
ALTER TABLE `web_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `web_comments`
--
ALTER TABLE `web_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Индексы таблицы `web_links`
--
ALTER TABLE `web_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `web_options`
--
ALTER TABLE `web_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Индексы таблицы `web_postmeta`
--
ALTER TABLE `web_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `web_posts`
--
ALTER TABLE `web_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `web_termmeta`
--
ALTER TABLE `web_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `web_terms`
--
ALTER TABLE `web_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `web_term_relationships`
--
ALTER TABLE `web_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `web_term_taxonomy`
--
ALTER TABLE `web_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `web_usermeta`
--
ALTER TABLE `web_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `web_users`
--
ALTER TABLE `web_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `web_commentmeta`
--
ALTER TABLE `web_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `web_comments`
--
ALTER TABLE `web_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `web_links`
--
ALTER TABLE `web_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `web_options`
--
ALTER TABLE `web_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT для таблицы `web_postmeta`
--
ALTER TABLE `web_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `web_posts`
--
ALTER TABLE `web_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `web_termmeta`
--
ALTER TABLE `web_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `web_terms`
--
ALTER TABLE `web_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `web_term_taxonomy`
--
ALTER TABLE `web_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `web_usermeta`
--
ALTER TABLE `web_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `web_users`
--
ALTER TABLE `web_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
